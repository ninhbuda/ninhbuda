import json
import os

file_path = 'use.txt'

key = "nezuko-chan"
admin = []
group = []

ho_tro = """
╔══════════════╗
║          Lệnh trên server:            ║
╠═════════════╣
║ 🔓 **mochat**: Mở khóa        ║
║ 🔒 **camchat**: Khóa mõm      ║
║ 📊 **bangxh**: bxh chat            ║
╚═════════════╝
"""



contronl = ["mochat" , "khoachat" , "HT" , "bangxh"]



def Getkey():
    return key

def Add_Admin(ad):
    admin.append(ad)
    
def Check(ad):
    if ad in admin:
        return True 
    else:
        return False

def Add_Grop(gr):
    group.append(gr)
    
def Check_Grop(gr):
    if gr in group:
        return True
    else:
        return False

def Check_Lenh(text):
    if text in contronl:
        return contronl.index(text)
    else:
        return -1
def Remove(text):
    if text in group:
        group.remove(text)  
        
def ConCac():
    return ho_tro
    
        