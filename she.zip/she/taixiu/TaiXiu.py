import json
import random

Gitcode = {
    "Test": 500000,
    "TanThu": 5000
}

def Tai_Xiu(ID , Box , type , vnd):
    if get_vnd(ID , Box) >= vnd:
        update_pem(ID , Box, get_pem(ID , Box) + vnd)
        xc1 = random.randint(1 , 6)
        xc2 = random.randint(1 , 6)
        xc3 = random.randint(1 , 6)
        
        Ve = 0 if (xc1 + xc2 + xc3) <= 10 else 1
        KetQua = "xỉu" if Ve == 0 else "tài"
        if type == Ve:
            update_vnd(ID , Box , get_vnd(ID , Box) + vnd)
            return f"Về bờ \n xúc sắc 1 : {xc1}\n xúc sắc 2 : {xc2} \n xúc sắc 3 : {xc3}\n kết quả : {KetQua} \n bú {format_currency(vnd)}"
        else:
            update_vnd(ID , Box , get_vnd(ID , Box) - vnd)
            return f"Xa bờ \n xúc sắc 1 : {xc1}\n xúc sắc 2 : {xc2} \n xúc sắc 3 : {xc3}\n kết quả : {KetQua} \n trừ {format_currency(vnd)}"
        
      
    else:
        return "Số dư không đủ"

def info(ID , BOX , Name):
    return f"Name : {Name}\nUID : {ID}\nSố tiền : {format_currency(get_vnd(ID , BOX))}\nSố tiền đã đánh : {format_currency(get_pem(ID , BOX))}"

    
def register_account(ID , Box):
    account = {
        "uid": ID,
        "box": Box,
        "vnd": 0,
        "tong_pem": 0
    }
    try:
        with open('accounts.json', 'r') as file:
            accounts = json.load(file)
    except FileNotFoundError:
        accounts = []
    accounts.append(account)
    with open('accounts.json', 'w') as file:
        json.dump(accounts, file, indent=4)
    
    print("Đăng ký thành công!")

def get_vnd(ip , Box):
    try:
        with open('accounts.json', 'r') as file:
            accounts = json.load(file)
        for account in accounts:
            if account['uid'] == ip and account['box'] == Box:
                return account['vnd']

        return -1
    except FileNotFoundError:
        return -1
        
def get_pem(ip , Box):
    try:
        with open('accounts.json', 'r') as file:
            accounts = json.load(file)
        for account in accounts:
            if account['uid'] == ip and account['box'] == Box:
                return account['tong_pem']

        return -1
    except FileNotFoundError:
        return -1
                
def update_vnd(ip, Box, new_vnd):
    try:
        with open('accounts.json', 'r+') as file:
            accounts = json.load(file)
            for account in accounts:
                if account['uid'] == ip and account['box'] == Box:
                    account['vnd'] = new_vnd
                    file.seek(0)
                    json.dump(accounts, file, indent=4)
                    file.truncate()
                    return True
        return False
    except FileNotFoundError:
        return False

def update_pem(ip, Box, new_pem):
    try:
        with open('accounts.json', 'r+') as file:
            accounts = json.load(file)
            for account in accounts:
                if account['uid'] == ip and account['box'] == Box:
                    account['tong_pem'] = new_pem
                    file.seek(0)
                    json.dump(accounts, file, indent=4)
                    file.truncate()
                    return True
        return False
    except FileNotFoundError:
        return False
        
def check_use(ip , box):
    try:
        with open('accounts.json', 'r') as file:
            accounts = json.load(file)

        for account in accounts:
            if account['uid'] == ip and account['box'] == box:
                return True

        return False
       
    except FileNotFoundError:
        return False           

def check_Code(code):
    if code in Gitcode:
        return True
    else:
        return False

def Nhap_code(id ,  box , code):
    if check_Code(code):
        if check_gitcode(id , box , code):
            add_gitcode_to_pl(id , box , code)
            update_vnd(id , box , get_vnd(id , box) + get_vnd_code(code))
            return f"nhập thành công code {code} cộng {get_vnd_code(code)}"
        else:
            return "Bạn đã nhập code này rồi"
    else:
        return "Gitcode không tồn tại"

def check_gitcode(ID , Box, Gitcode):
    try:
        with open('gitcode.json', 'r') as file:
            accounts = json.load(file)

        for account in accounts:
            if account['uid'] == ID and account['box'] == Box and account['code'] == Gitcode:
                return False

        return True
    except FileNotFoundError:
        return True        

def add_gitcode_to_pl(ID , Box , Gitcode):
    account = {
        "uid": ID,
        "box": Box,
        "code": Gitcode,
    }
    try:
        with open('gitcode.json', 'r') as file:
            accounts = json.load(file)
    except FileNotFoundError:
    
        accounts = []
    accounts.append(account)
    with open('gitcode.json', 'w') as file:
        json.dump(accounts, file, indent=4)
    
    print("Đăng ký thành công!")
    
def format_currency(amount):
    formatted_amount = "{:,}".format(amount)
    formatted_amount = formatted_amount.replace(',', '.')
    formatted_amount += " VNĐ"
    return formatted_amount

def bxh():
    with open("taixiu/accounts.json", 'r', encoding='utf-8') as file:
        data = json.load(file)
    new = sorted(data, key=lambda x: x['tong_pem'], reverse=True)[:10]
    Reload = "Bxh Toàn Server \n"
    i = 0;
    for item in new:
        i += 1
        Reload += f"Top {i}\nname {item['tong_pem']}\n"
    return Reload


def get_vnd_code(key):
    if key in Gitcode:
        amount = Gitcode[key]
        return amount

print (bxh())
    
print (info(93 , 50 , "Test"))                       
print (Tai_Xiu(93 , 50 , 0 , 10009))                    
